package br.com.projetofinal.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.projetofinal.model.PDV;

public interface PDVDAO extends CrudRepository<PDV,Integer>{

}
